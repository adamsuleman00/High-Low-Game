/* This is a simple game to guess if you have rolled higher or lower than the computer */
/* Adam Suleman */
/* Version 1.3 */
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
  int player_number, computer_number;
  string player_choice;
  string restart_choice;

/* initialize random seed: */
  srand(time(0));
/* generate secret number: */
  computer_number = (rand () % 10) + 1;
  player_number = (rand () % 10) + 1;

/* player has to guess whether rolled dice higher/lower */
  cout << "Higher or Lower (higher/lower)" << endl;
  cin >> player_choice;

/* decides whos the winner */
  if ((player_number > computer_number) && player_choice == "higher") 
      cout << "You Won!" << endl;
  else if ((player_number < computer_number) && player_choice == "lower")
      cout << "You Won!" << endl;
  else if ((player_number < computer_number) && player_choice == "higher") 
      cout << "You Lose!" << endl;
  else if ((player_number > computer_number) && player_choice == "lower")
      cout << "You Lose!" << endl;
  else 
      cout << "Its a tie!" << endl;

  cout << "Computer rolled: " << computer_number << endl;
  cout << "Player rolled: " << player_number << endl;
  
  /* player can restart or continue with the game */
  cout << "Restart game ? Yes or No (y/n)" << endl;
  cin >> restart_choice;

  if (restart_choice == "y") 
      int main();
  else 
      {}
}