/* This is a simple game to guess if you have rolled higher or lower than the computer */
/* Adam Suleman */
/* Version 1 */
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
  int player_number, computer_number;
  
/* initialize random seed: */
  srand(time(0));

/* generate secret number: */
  computer_number = (rand () % 10) + 1;
  player_number = (rand () % 10) + 1;

/* decides whos the winner */
  if (player_number > computer_number)
      cout << "You Won!" << endl;
  else if (player_number < computer_number)
      cout << "You lose!" << endl;
  else 
      cout << "Its a tie!" << endl;

  cout << "Computer rolled: " << computer_number << endl;
  cout << "Player rolled: " << player_number << endl;


}